
# InstaGate — Starter (RN CLI + Node API)

This is a monorepo scaffold for **InstaGate**: React Native (iOS-first) + Node/Express API, with workspaces and CI hooks.

## Quick Start
```bash
# macOS prerequisites: Xcode + CocoaPods, Node 20, Watchman
cd instagate-starter
pnpm install
pnpm run setup     # generates native RN app (apps/mobile) and installs pods
# In one terminal
pnpm dev:api
# In another terminal
cd apps/mobile/ios && pod install
open apps/mobile/ios/*.xcworkspace  # build & run in Xcode
```

## Structure
- `apps/mobile` — React Native app (TypeScript). Native iOS/Android created by setup script.
- `apps/api` — Express API (TypeScript-ready via tsconfig).
- `packages/shared` — Shared constants/types.

## Notes
- API listens on `http://127.0.0.1:4000` (see `/events` endpoint).
- Mobile `App.tsx` fetches sample events.
- Add Stripe, OAuth providers, and Sentry when ready.

## License
MIT


---

## Payments & OAuth (Scaffold)
- **Stripe**: set `STRIPE_SECRET_KEY` and `STRIPE_WEBHOOK_SECRET` in `apps/api/.env` (copy from `.env.example`).  
  - Start tunneling (e.g., `stripe listen --forward-to localhost:4000/webhook/stripe`) for local webhooks.
  - The mobile app calls `payments/create-payment-intent`; confirm on-device with Stripe RN SDK later.

- **OAuth Providers** (Google, Apple, Microsoft, TikTok): routes scaffolded at `/auth/oauth/:provider/callback` expecting `providerToken`.
  - Replace with real provider SDKs on mobile and verify tokens server-side before issuing session JWTs.

## Dev tips
- iOS payments **don’t** use Apple IAP here because the product is a *real-world event ticket/badge* (Stripe OK). For digital-only content, follow Apple IAP rules.
- For device testing, replace `127.0.0.1` with your Mac's LAN IP in `src/auth.ts` and `src/payments.ts`.


## Tickets: QR & Apple Wallet (Scaffold)
- **Issue QR Ticket:** `POST /tickets/issue` with `{ eventId, userId }` → returns `{ qrDataUrl, code }`.
- **Validate at Door:** `POST /tickets/validate` with `{ code }` → verifies HMAC and marks ticket checked_in.
- **Apple Wallet (.pkpass):** `POST /tickets/pass/pkpass` returns 501 now. Add Apple certificates (WWDR + Pass Type ID) and integrate a PKPass library to generate signed passes.
- **Signing:** set `TICKET_SIGNING_SECRET` in `apps/api/.env`.
