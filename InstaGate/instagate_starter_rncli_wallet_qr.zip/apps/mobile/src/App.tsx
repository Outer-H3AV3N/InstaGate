
import React, {useEffect, useState} from 'react';
import { SafeAreaView, Text, View, Button, FlatList, Alert } from 'react-native';
import { signInWithProvider } from './auth';
import { createPaymentIntent } from './payments';
import { Ticket } from './Ticket';

export default function App() {
  const [events, setEvents] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [user, setUser] = useState<any>(null);

  useEffect(() => {
    (async () => {
      try {
        setLoading(true);
        const res = await fetch('http://127.0.0.1:4000/events');
        const json = await res.json();
        setEvents(json);
      } catch (e) {
        console.log('API not reachable yet:', e);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const handleSignIn = async (provider: any) => {
    try {
      const result = await signInWithProvider(provider);
      setUser(result.user);
      Alert.alert('Signed in', JSON.stringify(result.user));
    } catch (e) {
      Alert.alert('Auth error', String(e));
    }
  };

  const handlePay = async (eventId: string) => {
    try {
      const pi = await createPaymentIntent(10, eventId);
      Alert.alert('PaymentIntent created', JSON.stringify(pi));
      // TODO: Confirm payment with Stripe SDK on-device
    } catch (e) {
      Alert.alert('Payment error', String(e));
    }
  };

  return (
    <SafeAreaView style={{flex:1, padding:16}}>
      <View style={{alignItems:'center'}}>
        <Text style={{fontSize:22, fontWeight:'700'}}>InstaGate — The Wall</Text>
        <Text>Start Something.</Text>
      </View>

      <View style={{marginVertical:12, gap:8}}>
        <Text style={{fontWeight:'600'}}>Sign in (scaffold):</Text>
        <View style={{flexDirection:'row', gap:8, justifyContent:'space-between'}}>
          <Button title="Google" onPress={() => handleSignIn('google')} />
          <Button title="Apple" onPress={() => handleSignIn('apple')} />
          <Button title="Microsoft" onPress={() => handleSignIn('microsoft')} />
          <Button title="TikTok" onPress={() => handleSignIn('tiktok')} />
        </View>
      </View>

      {loading ? <Text>Loading…</Text> : (
        <FlatList
          data={events}
          keyExtractor={(item) => item.id}
          renderItem={({item}) => (
            <View style={{padding:12, borderWidth:1, borderRadius:8, marginBottom:8}}>
              <Text style={{fontWeight:'600'}}>{item.title}</Text>
              <Text>$10.00</Text>
              <View style={{marginTop:8}}>
                <Button title="Contribute $10" onPress={() => handlePay(item.id)} />
              </View>
            </View>
          )}
          ListEmptyComponent={<Text>No events yet</Text>}
        />
      )}
          {user && <Ticket user={user} />}
    </SafeAreaView>
  );
}
