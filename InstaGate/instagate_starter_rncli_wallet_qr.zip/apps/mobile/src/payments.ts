
export async function createPaymentIntent(amount: number, eventId: string) {
  const res = await fetch('http://127.0.0.1:4000/payments/create-payment-intent', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ amount, eventId, currency: 'usd' }),
  });
  return res.json();
}
