
import React, { useState } from 'react';
import { View, Text, Button, Image, Alert } from 'react-native';

export function Ticket({ user }: { user: any }) {
  const [qr, setQr] = useState<string | null>(null);
  const [code, setCode] = useState<string | null>(null);

  const issue = async () => {
    try {
      const res = await fetch('http://127.0.0.1:4000/tickets/issue', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ eventId: 'evt_1', userId: user?.id ?? 'user_mock' })
      });
      const json = await res.json();
      if (json.qrDataUrl) setQr(json.qrDataUrl);
      if (json.code) setCode(json.code);
    } catch (e) {
      Alert.alert('Ticket error', String(e));
    }
  };

  const validate = async () => {
    try {
      const res = await fetch('http://127.0.0.1:4000/tickets/validate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code })
      });
      const json = await res.json();
      Alert.alert('Validation', JSON.stringify(json));
    } catch (e) {
      Alert.alert('Validation error', String(e));
    }
  };

  return (
    <View style={{marginTop:16, alignItems:'center'}}>
      <Text style={{fontWeight:'700'}}>Your Ticket</Text>
      <Button title="Get Ticket" onPress={issue} />
      {qr && <Image source={{ uri: qr }} style={{ width: 220, height: 220, marginTop: 12 }} />}
      {code && <Button title="Validate (simulate check-in)" onPress={validate} />}
    </View>
  );
}
