
export async function signInWithProvider(provider: 'google' | 'apple' | 'microsoft' | 'tiktok') {
  // TODO: Integrate native SDKs (Sign in with Apple, Google Sign-In, MSAL, TikTok)
  // For now, simulate obtaining a provider token and call backend
  const providerToken = 'mock-provider-token';
  const res = await fetch('http://127.0.0.1:4000/auth/oauth/' + provider, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ providerToken })
  });
  return res.json();
}
