
import { Router } from 'express';
import QRCode from 'qrcode';
import { v4 as uuidv4 } from 'uuid';
import { makeCode, verifyCode } from './signing.js';

const router = Router();

// In-memory tickets (scaffold). Replace with DB later.
const TICKETS = new Map();

// Issue a ticket/badge for an event -> returns QR data URL
router.post('/issue', async (req, res) => {
  try {
    const { eventId, userId } = req.body || {};
    if (!eventId || !userId) return res.status(400).json({ error: 'eventId and userId required' });

    const id = uuidv4();
    const payload = { sub: userId, evt: eventId, tix: id, iat: Date.now() };
    const code = makeCode(payload); // signed compact token
    const qrDataUrl = await QRCode.toDataURL(code, { errorCorrectionLevel: 'M' });

    const record = { id, eventId, userId, code, issuedAt: new Date().toISOString(), status: 'issued' };
    TICKETS.set(id, record);

    res.json({
      ticketId: id,
      eventId,
      userId,
      qrDataUrl,
      code,
      status: 'issued'
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'ticket_issue_error', details: String(err) });
  }
});

// Validate a ticket code (for venue check-in)
router.post('/validate', (req, res) => {
  const { code } = req.body || {};
  if (!code) return res.status(400).json({ valid: false, reason: 'code required' });
  const payload = verifyCode(code);
  if (!payload) return res.status(400).json({ valid: false, reason: 'invalid signature' });

  const ticket = [...TICKETS.values()].find(t => t.id === payload.tix);
  if (!ticket) return res.status(404).json({ valid: false, reason: 'not found' });
  if (ticket.status !== 'issued') return res.status(400).json({ valid: false, reason: 'not active' });

  // Mark as checked-in (idempotent-friendly)
  ticket.status = 'checked_in';
  res.json({ valid: true, ticketId: ticket.id, payload, status: ticket.status });
});

// Placeholder for Apple Wallet (.pkpass) generation
router.post('/pass/pkpass', async (_req, res) => {
  // NOTE: Implement with a PKPass library and Apple certificates:
  // - Apple WWDR CA, Pass Type ID certificate (.p12), team identifiers
  // - Sign pass.json, bundle assets, return application/vnd.apple.pkpass
  res.status(501).json({ error: 'not_implemented', message: 'Apple Wallet pass generation will be added with certificates.' });
});

export default router;
