
#!/usr/bin/env bash
set -euo pipefail

# Ensure PNPM via Corepack
if ! command -v corepack >/dev/null 2>&1; then
  echo "Enabling Corepack..."
fi
corepack enable || true
corepack prepare pnpm@latest --activate || true

# Install root deps (none yet, but prepares lockfile)
pnpm install

# Initialize React Native app via CLI (iOS/Android native projects)
if [ ! -d "apps/mobile" ]; then
  mkdir -p apps
  pushd apps >/dev/null
  npx react-native@latest init mobile --template react-native-template-typescript
  popd >/dev/null
fi

# Install mobile workspace deps
pnpm --filter @instagate/mobile install || true

echo "Setup complete. Next:"
echo "  1) cd apps/mobile/ios && pod install"
echo "  2) Open apps/mobile/ios/*.xcworkspace in Xcode"
echo "  3) pnpm dev:api (in another terminal) to run the API"
