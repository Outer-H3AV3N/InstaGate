
import { Router } from 'express';
import Stripe from 'stripe';
import { config } from './config.js';

const router = Router();
const stripe = new Stripe(config.stripeSecretKey || '', { apiVersion: '2024-06-20' });

// Create a PaymentIntent for an event contribution
router.post('/create-payment-intent', async (req, res) => {
  try {
    const { amount, currency = 'usd', eventId, userId } = req.body || {};
    if (!amount || !eventId) return res.status(400).json({ error: 'amount and eventId required' });

    const pi = await stripe.paymentIntents.create({
      amount: Math.round(Number(amount) * 100),
      currency,
      metadata: { eventId, userId }
    });

    res.json({ clientSecret: pi.client_secret, paymentIntentId: pi.id });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'stripe_error', details: String(err) });
  }
});

// Webhook to handle async events (e.g., payment.succeeded)
router.post('/webhook', (req, res) => {
  try {
    const sig = req.headers['stripe-signature'];
    const payload = req.rawBody || req.body; // rawBody handled by server setup

    let event;
    if (config.stripeWebhookSecret && sig) {
      const stripe = new Stripe(config.stripeSecretKey || '', { apiVersion: '2024-06-20' });
      event = stripe.webhooks.constructEvent(payload, sig, config.stripeWebhookSecret);
    } else {
      // For local dev without webhook signing
      event = req.body;
    }

    switch (event.type) {
      case 'payment_intent.succeeded':
        // TODO: mark ticket/badge as issued, notify host/attendee
        break;
      default:
        break;
    }

    res.json({ received: true });
  } catch (err) {
    console.error('Webhook error', err);
    res.status(400).send(`Webhook Error: ${err.message}`);
  }
});

export default router;
