
import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import cookieParser from 'cookie-parser';
import morgan from 'morgan';
import { config } from './config.js';
import payments from './payments.js';
import auth from './auth.js';

const app = express();

// Stripe webhook needs raw body; apply conditionally
app.use((req, res, next) => {
  if (req.originalUrl === '/webhook/stripe') {
    // capture raw body for Stripe verification
    let data = '';
    req.setEncoding('utf8');
    req.on('data', (chunk) => data += chunk);
    req.on('end', () => {
      req.rawBody = data;
      next();
    });
  } else {
    next();
  }
});

app.use(helmet());
app.use(morgan('dev'));
app.use(cors({ origin: true, credentials: true }));
app.use(cookieParser());
app.use(express.json());

const limiter = rateLimit({ windowMs: 60_000, max: 120 });
app.use(limiter);

// Health
app.get('/health', (_req, res) => res.json({ ok: true, service: 'api' }));

// Demo resources
app.get('/events', (_req, res) => {
  res.json([{ id: 'evt_1', title: 'Tesla Meet', price: 10 }]);
});
app.post('/events', (req, res) => {
  const { title, price } = req.body || {};
  if (!title) return res.status(400).json({ error: 'title required' });
  res.status(201).json({ id: 'evt_new', title, price: price ?? 0 });
});

// Auth & Payments
app.use('/auth', auth);
app.use('/payments', payments);
app.post('/webhook/stripe', payments);

// Start
app.listen(config.port, () => {
  console.log(`API running on :${config.port}`);
});
