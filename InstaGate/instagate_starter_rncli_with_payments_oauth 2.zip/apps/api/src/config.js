
import 'dotenv/config';

export const config = {
  env: process.env.NODE_ENV ?? 'development',
  port: Number(process.env.PORT ?? 4000),
  jwtSecret: process.env.JWT_SECRET ?? 'change-me',
  clientBaseUrl: process.env.CLIENT_BASE_URL ?? 'http://localhost:19006',

  // Stripe
  stripeSecretKey: process.env.STRIPE_SECRET_KEY ?? '',
  stripeWebhookSecret: process.env.STRIPE_WEBHOOK_SECRET ?? '',

  // OAuth (scaffold variables)
  oauth: {
    google: { clientId: process.env.GOOGLE_CLIENT_ID ?? '', clientSecret: process.env.GOOGLE_CLIENT_SECRET ?? '' },
    apple: { clientId: process.env.APPLE_CLIENT_ID ?? '', teamId: process.env.APPLE_TEAM_ID ?? '', keyId: process.env.APPLE_KEY_ID ?? '', privateKey: process.env.APPLE_PRIVATE_KEY ?? '' },
    microsoft: { clientId: process.env.MS_CLIENT_ID ?? '', clientSecret: process.env.MS_CLIENT_SECRET ?? '' },
    tiktok: { clientKey: process.env.TIKTOK_CLIENT_KEY ?? '', clientSecret: process.env.TIKTOK_CLIENT_SECRET ?? '' },
  }
};
