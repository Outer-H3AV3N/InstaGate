
import { Router } from 'express';
import jwt from 'jsonwebtoken';
import { config } from './config.js';

const router = Router();

// NOTE: This is an OAuth scaffold. In production, integrate actual providers or use a broker like Auth0.
// For now, we accept a provider token from the client and issue a signed session JWT after minimal verification.

router.post('/oauth/:provider/callback', async (req, res) => {
  const { provider } = req.params;
  const { providerToken } = req.body || {};

  // TODO: verify providerToken with the provider's introspection endpoint
  if (!providerToken) return res.status(400).json({ error: 'providerToken required' });

  // Fake profile from provider
  const profile = { id: 'user_mock', email: 'user@example.com', provider };

  const token = jwt.sign({ sub: profile.id, email: profile.email, provider }, config.jwtSecret, { expiresIn: '7d' });
  res.json({ token, user: { id: profile.id, email: profile.email, provider } });
});

export default router;
