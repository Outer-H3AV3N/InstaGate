
import React, {useEffect, useState} from 'react';
import { SafeAreaView, Text, View, Button, FlatList } from 'react-native';

export default function App() {
  const [events, setEvents] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        setLoading(true);
        const res = await fetch('http://127.0.0.1:4000/events');
        const json = await res.json();
        setEvents(json);
      } catch (e) {
        console.log('API not reachable yet:', e);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  return (
    <SafeAreaView style={{flex:1, padding:16}}>
      <View style={{alignItems:'center'}}>
        <Text style={{fontSize:22, fontWeight:'700'}}>InstaGate — The Wall</Text>
        <Text>Start Something.</Text>
      </View>
      <View style={{marginVertical:12}}>
        <Button title="Refresh" onPress={() => {}} />
      </View>
      {loading ? <Text>Loading…</Text> : (
        <FlatList
          data={events}
          keyExtractor={(item) => item.id}
          renderItem={({item}) => (
            <View style={{padding:12, borderWidth:1, borderRadius:8, marginBottom:8}}>
              <Text style={{fontWeight:'600'}}>{item.title}</Text>
              <Text>${"{:.2f}".format(10)}</Text>
            </View>
          )}
          ListEmptyComponent={<Text>No events yet</Text>}
        />
      )}
    </SafeAreaView>
  );
}
