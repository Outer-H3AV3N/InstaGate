
import 'dotenv/config';
import express from 'express';
import cors from 'cors';

const app = express();
app.use(cors());
app.use(express.json());

// Health check
app.get('/health', (_req, res) => res.json({ ok: true, service: 'api' }));

// Example: events listing (placeholder)
app.get('/events', (_req, res) => {
  res.json([{ id: 'evt_1', title: 'Tesla Meet', price: 10 }]);
});

// Example: create event (placeholder)
app.post('/events', (req, res) => {
  const { title, price } = req.body || {};
  if (!title) return res.status(400).json({ error: 'title required' });
  res.status(201).json({ id: 'evt_new', title, price: price ?? 0 });
});

const port = process.env.PORT ?? 4000;
app.listen(port, () => {
  console.log(`API running on :${port}`);
});
