
# InstaGate — Starter (RN CLI + Node API)

This is a monorepo scaffold for **InstaGate**: React Native (iOS-first) + Node/Express API, with workspaces and CI hooks.

## Quick Start
```bash
# macOS prerequisites: Xcode + CocoaPods, Node 20, Watchman
cd instagate-starter
pnpm install
pnpm run setup     # generates native RN app (apps/mobile) and installs pods
# In one terminal
pnpm dev:api
# In another terminal
cd apps/mobile/ios && pod install
open apps/mobile/ios/*.xcworkspace  # build & run in Xcode
```

## Structure
- `apps/mobile` — React Native app (TypeScript). Native iOS/Android created by setup script.
- `apps/api` — Express API (TypeScript-ready via tsconfig).
- `packages/shared` — Shared constants/types.

## Notes
- API listens on `http://127.0.0.1:4000` (see `/events` endpoint).
- Mobile `App.tsx` fetches sample events.
- Add Stripe, OAuth providers, and Sentry when ready.

## License
MIT
