
export const APP_NAME = 'InstaGate';
export const SLOGAN = 'Start Something.';
